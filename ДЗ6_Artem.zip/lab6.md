Лабораторна робота
Ця лабораторна робота — перша частина більшого блоку, присвяченого практичному аналізу безпеки вебзастосунків. Ви починаєте з найважливішого — перевірки OWASP Juice Shop, спеціально створеного вразливого застосунку, який дозволяє навчитися безпечно досліджувати типові вразливості.


На цьому етапі ви:

проведете DAST-аналіз (динамічний) за допомогою OWASP ZAP, імітуючи дії зловмисника в браузері,
запустите SAST-аналіз (статичний) за допомогою Semgrep, щоб виявити проблеми безпеки без виконання коду,
навчитесь порівнювати ці два методи та розуміти їхні сильні та слабкі сторони.
Це не абстрактна теорія — ви отримаєте реальні звіти, побачите типові вразливості (SQL Injection, XSS, Hardcoded секрети тощо) та самостійно зможете оцінити, що саме «бачить» кожен підхід.

💡У реальних проєктах ці два типи тестування майже завжди застосовуються разом. Лабораторна допомагає вам відчути, як саме вони працюють і з якими класами проблем мають справу.


Усі отримані результати: збережені звіти, аналіз, таблицю порівняння — ви використаєте в наступному домашньому завданні. Це дозволить перейти від технічного виконання до більш аналітичного рівня — розуміння, коли, як і для чого застосовуються різні підходи.

Мета завдання:

Навчитися запускати DAST‑сканування OWASP Juice Shop за допомогою OWASP ZAP.
Провести статичний аналіз коду Juice Shop за допомогою Semgrep.
Порівняти результати обох підходів і зрозуміти їхні сильні та слабкі сторони.


Підготовка середовища

1. Клонуйте репозиторій Juice Shop

git clone <https://github.com/juice-shop/juice-shop.git> --depth 1 



cd juice-shop

Або скачайте архів із сайту github.com, після чого розархівуйте в папку для лабораторної роботи.




2. Запустіть Juice Shop у Docker



1. Відкрийте PowerShell, термінал або CMD.

2. Запустіть команду:

**docker run -d -p 3000:3000 bkimminich/juice-shop**

3. Або, використовуючи десктопну версію Docker, запустіть bkimminich/juice-shop з параметрами: порт 3000.

4. Для перевірки працездатності Juice Shop відкрите у браузері: http://localhost:3000

Якщо побачите сторінку Juice Shop, значить, контейнер запустився вдало й можна переходити до інших кроків.



Частина 1: DAST із ZAP

1. Встановіть або запустіть OWASP ZAP (GUI або CLI).

2. Запустіть автоскан, попередньо ввівши URL http://localhost:3000 та натиснувши «Attack»:






Або через консоль:

zap-cli quick-scan --self-contained --start-options '-daemon -host 0.0.0.0 -port 8080' http://localhost:3000



3. Після закінчення збережіть звіт у папку з лабораторною роботою:




Або командою:

zap-cli report -o zap_results.html -f html

4. Проаналізуйте й оцініть знайдені критичні та високі вразливості.



Частина 2: SAST із Semgrep у Docker

1. Завантажте образ semgrep/semgrep:latest з Docker Hub

2. Відкрийте PowerShell, термінал або CMD.

3. Запустіть команду:



docker run --rm -v "$(pwd)":/src returntocorp/semgrep semgrep --config p/owasp-top-ten /src --json -o results_semgrep.json




4. Дочекайтесь кінця перевірки.






5. Проаналізуйте звіт, зверніть увагу на знахідки:



SQL Injection
Hardcoded JWT Secret
XSS або unsafe crypto
Path Traversal
Тощо


Чому Semgrep підходить для нашої роботи:

Він підтримує JavaScript / TypeScript, що включено в архітектуру Juice Shop.
У Juice Shop він може знайти критичні вразливості SQLi, XSS, hardcoded values тощо.


Частина 3: Аналіз результатів і порівняння

1. Заповніть таблицю:

| Тип тесту | Топ‑3 знайдені вразливості | Цінність контексту | False positives?* | Коментар |
|---|---|---|---|---|
| **SAST (Semgrep)** | 1) SQL Injection (multiple locations — `routes/search.ts`, `routes/login.ts`, `data/static/codefixes`)  2) Hard‑coded JWT secret (`lib/insecurity.ts`)  3) Unsafe `eval` / code‑injection (`routes/userProfile.ts`) | Дає точні рядки/файли — корисно для пошуку hardcoded секретів, pattern‑level issues і data‑flow | **Ні** — багато знахідок навмисні (навчальні challenge) | Semgrep знайшов 18 знахідок; повний JSON‑звіт: `results_semgrep.json`. |
| **DAST (ручне тестування)** | 1) **Stored XSS** — `/rest/products/:id/reviews` (вставлений HTML/JS повертається у JSON та може виконуватися у фронтенді)  2) **Authentication bypass (SQLi)** — `/rest/user/login` (ін’єкція в `email` повертає токен адміністратора)  3) **SQL Injection (search)** — `/rest/products/search?q=` (boolean‑SQLi повертає некоректний/розширений набір рядків); додатково: доступна директорія `/encryptionkeys` (directory listing), витік стек‑трейсів у помилках, CORS `Access‑Control‑Allow‑Origin: *` | Імітує реальні атаки — підтверджує експлуатовані runtime‑вразливості і misconfigurations; високий ступінь цінності (PoC доступні) | **Ні** — runtime‑знахідки верифіковано доказами експлуатації (PoC) | ZAP локально не запущено (macOS/Docker обмеження). Натомість виконано ручний DAST (PoC наведено нижче). |




У цій роботі False positives можна вважати:
Якщо знаходите проблему, але розумієте, що вона навмисна (наприклад, у навчальному проєкті), вкажіть це в коментарі.

### DAST (ручне тестування) — знахідки та PoC

- Stored XSS (високий):
  - Endpoint: `PUT /rest/products/1/reviews` — тіло JSON: `{ "author": "attacker@example.com", "message": "<svg/onload=alert('xss')>" }`
  - Перевірка: `GET /rest/products/1/reviews` повертає поле `message` з HTML/JS (не екрановане).
  - Доказ: повідомлення з `<svg/onload=alert('xss')>` присутнє у відповіді (див. `GET /rest/products/1/reviews`).

- Authentication bypass — SQL Injection (критично):
  - Endpoint: `POST /rest/user/login` — тіло JSON: `{ "email": "' OR 1=1 -- ", "password": "x" }`
  - Результат: повертається `authentication.token` для адміністратора (успішний обхід автентифікації).
  - Доказ: відповідь містить `umail: "admin@juice-sh.op"` та токен.

- SQL Injection — search (високий):
  - Endpoint: `GET /rest/products/search?q=<payload>`
  - PoC (boolean): `q=' OR '1'='1' -- ` — повертає розширений набір результатів (SQLi підтверджено).
  - PoC (error disclosure): `q=' UNION SELECT sql FROM sqlite_master -- ` — викликає SQL‑помилку з фрагментом згенерованого SQL (витік).

- Інші конфігураційні/інформаційні проблеми (середні/низькі):
  - Directory listing: `GET /encryptionkeys` (видимі ключі/файли).  
  - Security headers: `Access‑Control‑Allow‑Origin: *` (CORS wildcard); відсутній CSP / HSTS.  
  - Stacktraces visible in error pages (інформаційне розкриття). 

> Команди‑PoC (копіюй/виконуй локально):
> - `curl -X PUT http://localhost:3000/rest/products/1/reviews -H 'Content-Type: application/json' -d '{"author":"attacker@example.com","message":"<svg/onload=alert(\'xss\')>"}'`
> - `curl -H 'Accept: application/json' http://localhost:3000/rest/products/1/reviews`
> - `curl -X POST http://localhost:3000/rest/user/login -H 'Content-Type: application/json' -d '{"email":"' OR 1=1 -- ","password":"x"}' -i`
> - `curl -H 'Accept: application/json' "http://localhost:3000/rest/products/search?q=%27%20OR%20%271%27%3D%271%20--%20"`

---



Якщо Semgrep вказує на проблему у файлі, який зазвичай не використовується в production або не є активною частиною бекенду.



Чекліст перед початком домашнього завдання

Перш ніж переходити до виконання домашнього завдання, переконайтесь, що у вас є результати лабораторної роботи:

- Звіт або скриншоти з OWASP ZAP

Проведено DAST-аналіз, знайдено щонайменше 5 вразливостей.
- Звіт або скриншоти з Semgrep

Проведено SAST-аналіз, знайдено щонайменше 3 вразливості.
- Заповнена таблиця «SAST vs DAST»

Вказано, що виявляє кожен метод, які переваги і недоліки.
- Короткий висновок (2–3 речення)

SAST (Semgrep) швидко знаходить проблемні ділянки в коді — hardcoded секрети, pattern‑based SQLi/XSS; DAST (ZAP) підтверджує експлуатацію та виявляє runtime‑проблеми (XSS, insecure headers). Разом вони доповнюють одне одного: SAST дає контекст у коді, DAST — підтвердження поведінки на runtime.

У чому користь SAST? У чому — DAST?


Ці матеріали ви будете використовувати в домашньому завданні. Окремо їх здавати не потрібно — усе має бути в одному підсумковому документі.