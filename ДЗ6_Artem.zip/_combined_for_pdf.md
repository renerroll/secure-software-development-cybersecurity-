# Підсумок домашнього завдання — Аналіз безпеки (SAST / DAST / IAST / RASP)

Коротко: цей файл — стисла та структурована відповідь на пункти з `task.md` (завдання 1–3). Усі технічні артефакти — у робочій папці (Semgrep звіт: `results_semgrep.json`; DAST — ручні PoC записані в `lab6.md`).

---

## 1) Комбінація підходів (Task 1) ✅
Таблиця: вразливість → метод виявлення → інструмент → етап SSDLC

| Вразливість | Можна виявити через | Інструмент | Етап SSDLC |
|---|---:|---|---|
| Hard‑coded JWT secret | ✅ SAST | Semgrep (`lib/insecurity.ts`) | Pull request / pre‑commit |
| SQL Injection (raw queries / ORM) | ✅ SAST, ✅ DAST, ✅ IAST | Semgrep; ручний DAST PoC; IAST (agent) | Code review + Integration tests |
| Stored XSS (reviews) | ✅ DAST, ✅ SAST (частково) | OWASP ZAP (DAST) / manual PoC; Semgrep (pattern) | Staging / runtime testing |
| Unsafe `eval` / Code injection | ✅ SAST, ✅ IAST | Semgrep (`routes/userProfile.ts`); IAST taint traces | Commit / Integration tests |
| Directory listing / exposed keys | ✅ SAST (config), ✅ DAST (runtime) | Semgrep (`fileServer.ts`) + manual HTTP checks (`/encryptionkeys`) | Pre‑deploy scan + staging |
| Open redirect / insecure redirects | ✅ SAST, ✅ DAST | Semgrep (`routes/redirect.ts`) + runtime test | PR checks + staging |

(додаткові деталі й PoC — у `lab6.md`)

---

## 2) Практична симуляція: інтеграція IAST (Task 2) 💡
Вибір: інтегрувати **IAST‑агент** у тестове середовище Juice Shop.

Кроки / середовище:
- Інструмент: Contrast Assess / Seeker / Veracode IAST (приклад). Агент встановлюється поруч із node.js-програмою в тестовому контейнері.
- Де запускати: інтеграційні тести в CI (GitHub Actions) або окрема stage‑середа зі штатними E2E тестами (Cypress/Playwright).
- Які тести: повні API‑інтеграційні тести + фази функціонального сканування (login, search, reviews, file serve).

Очікувані результати / приклад виявлення:
- IAST проводить taint‑tracking: запит → параметр `q` у `/rest/products/search` помічено як tainted → детектує SQLi у `models.sequelize.query(...)` → повертає стек‑трейс, HTTP-запит і фрагмент уразливого коду.
- Аналогічно IAST вкаже на stored XSS у механізмі зберігання відгуків і на hardcoded секрети при інструментальній перевірці конфігурації.

Практична цінність:
- Менше false‑positives, бо IAST працює із runtime‑контекстом; дозволяє пріоритезувати вразливості за експлуатованістю.

---

## 3) Вибір інструментів за типом застосунку (Task 3) 🔧

A) SPA (Angular фронтенд)
- Рекомендовані тести: SAST (JS/TS), DAST (runtime), SCA (залежності), E2E‑security checks.
- Інструменти: Semgrep / ESLint (SAST), OWASP ZAP або Burp (DAST), Snyk/Dependabot (SCA), Cypress + security checks (E2E).
- Інтеграція в pipeline:
  1. PR → Semgrep + ESLint (block on high severity).  
  2. CI build → SCA (PR alerts).  
  3. Nightly staging → DAST (ZAP baseline) + E2E security scenarios.

B) REST API (Node/Express backend)
- Рекомендовані тести: SAST, IAST (integration), DAST (API fuzzing), SCA, runtime logging/monitoring.
- Інструменти: Semgrep (SAST), Contrast (IAST), OWASP ZAP / Postman + Fuzz (DAST), Snyk (SCA).
- Інтеграція в pipeline:
  1. Pre‑merge SAST (Semgrep).  
  2. CI integration: run unit + integration tests with IAST agent attached.  
  3. Pre‑release/staging: automated DAST scan against deployed staging.  
  4. Post‑deploy: RASP / WAF + monitoring for runtime anomalies.

---

## Докази / артефакти (де шукати) 📂
- Semgrep (SAST) JSON‑звіт: `results_semgrep.json` (в робочій папці).  
- Ручні DAST PoC та опис — додані в `lab6.md` (stored XSS, SQLi auth bypass, directory listing, insecure headers).  
- Docker/Запуск Juice Shop: локально на `http://localhost:3000`.

---

## Чек‑лист для здачі (відповідно до критеріїв оцінювання) ✅
- [x] SAST: Semgrep запущено, `results_semgrep.json` — є (мінімум 3 вразливості).  
- [x] DAST: ZAP не вдалося запустити тут, але виконано ручні PoC (мінімум 5 runtime знахідок документовано в `lab6.md`).  
- [x] Порівняльна таблиця SAST vs DAST — є (у `lab6.md` та тут).  
- [x] Завдання 1 — таблиця з прикладами вразливостей — виконано.  
- [x] Завдання 2 — IAST‑сценарій — описано.  
- [x] Завдання 3 — вибір інструментів і pipeline — описано.  
- [x] Висновок (2–3 речення) — є нижче.

---

## Висновок (2–3 речення) ✨
SAST (Semgrep) дає швидкий зворотний зв'язок на рівні коду — ефективний для пошуку hardcoded секретів і pattern‑based issues. DAST підтверджує експлуатованість у runtime (XSS, auth bypass, misconfigurations); IAST додає точності, бо поєднує контекст коду й виконання. Рекомендовано комбінувати всі підходи у CI/CD: SAST → IAST (integration) → DAST (staging) + runtime‑monitoring.

---

Якщо хочеш — згенерую з цього `report.md` або PDF та прикріплю його до архіву для LMS. Хочеш, щоб я підготував готовий Google‑Doc/ZIP для здачі? 📤


---


Лабораторна робота
Ця лабораторна робота — перша частина більшого блоку, присвяченого практичному аналізу безпеки вебзастосунків. Ви починаєте з найважливішого — перевірки OWASP Juice Shop, спеціально створеного вразливого застосунку, який дозволяє навчитися безпечно досліджувати типові вразливості.


На цьому етапі ви:

проведете DAST-аналіз (динамічний) за допомогою OWASP ZAP, імітуючи дії зловмисника в браузері,
запустите SAST-аналіз (статичний) за допомогою Semgrep, щоб виявити проблеми безпеки без виконання коду,
навчитесь порівнювати ці два методи та розуміти їхні сильні та слабкі сторони.
Це не абстрактна теорія — ви отримаєте реальні звіти, побачите типові вразливості (SQL Injection, XSS, Hardcoded секрети тощо) та самостійно зможете оцінити, що саме «бачить» кожен підхід.

💡У реальних проєктах ці два типи тестування майже завжди застосовуються разом. Лабораторна допомагає вам відчути, як саме вони працюють і з якими класами проблем мають справу.


Усі отримані результати: збережені звіти, аналіз, таблицю порівняння — ви використаєте в наступному домашньому завданні. Це дозволить перейти від технічного виконання до більш аналітичного рівня — розуміння, коли, як і для чого застосовуються різні підходи.

Мета завдання:

Навчитися запускати DAST‑сканування OWASP Juice Shop за допомогою OWASP ZAP.
Провести статичний аналіз коду Juice Shop за допомогою Semgrep.
Порівняти результати обох підходів і зрозуміти їхні сильні та слабкі сторони.


Підготовка середовища

1. Клонуйте репозиторій Juice Shop

git clone <https://github.com/juice-shop/juice-shop.git> --depth 1 



cd juice-shop

Або скачайте архів із сайту github.com, після чого розархівуйте в папку для лабораторної роботи.




2. Запустіть Juice Shop у Docker



1. Відкрийте PowerShell, термінал або CMD.

2. Запустіть команду:

**docker run -d -p 3000:3000 bkimminich/juice-shop**

3. Або, використовуючи десктопну версію Docker, запустіть bkimminich/juice-shop з параметрами: порт 3000.

4. Для перевірки працездатності Juice Shop відкрите у браузері: http://localhost:3000

Якщо побачите сторінку Juice Shop, значить, контейнер запустився вдало й можна переходити до інших кроків.



Частина 1: DAST із ZAP

1. Встановіть або запустіть OWASP ZAP (GUI або CLI).

2. Запустіть автоскан, попередньо ввівши URL http://localhost:3000 та натиснувши «Attack»:






Або через консоль:

zap-cli quick-scan --self-contained --start-options '-daemon -host 0.0.0.0 -port 8080' http://localhost:3000



3. Після закінчення збережіть звіт у папку з лабораторною роботою:




Або командою:

zap-cli report -o zap_results.html -f html

4. Проаналізуйте й оцініть знайдені критичні та високі вразливості.



Частина 2: SAST із Semgrep у Docker

1. Завантажте образ semgrep/semgrep:latest з Docker Hub

2. Відкрийте PowerShell, термінал або CMD.

3. Запустіть команду:



docker run --rm -v "$(pwd)":/src returntocorp/semgrep semgrep --config p/owasp-top-ten /src --json -o results_semgrep.json




4. Дочекайтесь кінця перевірки.






5. Проаналізуйте звіт, зверніть увагу на знахідки:



SQL Injection
Hardcoded JWT Secret
XSS або unsafe crypto
Path Traversal
Тощо


Чому Semgrep підходить для нашої роботи:

Він підтримує JavaScript / TypeScript, що включено в архітектуру Juice Shop.
У Juice Shop він може знайти критичні вразливості SQLi, XSS, hardcoded values тощо.


Частина 3: Аналіз результатів і порівняння

1. Заповніть таблицю:

| Тип тесту | Топ‑3 знайдені вразливості | Цінність контексту | False positives?* | Коментар |
|---|---|---|---|---|
| **SAST (Semgrep)** | 1) SQL Injection (multiple locations — `routes/search.ts`, `routes/login.ts`, `data/static/codefixes`)  2) Hard‑coded JWT secret (`lib/insecurity.ts`)  3) Unsafe `eval` / code‑injection (`routes/userProfile.ts`) | Дає точні рядки/файли — корисно для пошуку hardcoded секретів, pattern‑level issues і data‑flow | **Ні** — багато знахідок навмисні (навчальні challenge) | Semgrep знайшов 18 знахідок; повний JSON‑звіт: `results_semgrep.json`. |
| **DAST (ручне тестування)** | 1) **Stored XSS** — `/rest/products/:id/reviews` (вставлений HTML/JS повертається у JSON та може виконуватися у фронтенді)  2) **Authentication bypass (SQLi)** — `/rest/user/login` (ін’єкція в `email` повертає токен адміністратора)  3) **SQL Injection (search)** — `/rest/products/search?q=` (boolean‑SQLi повертає некоректний/розширений набір рядків); додатково: доступна директорія `/encryptionkeys` (directory listing), витік стек‑трейсів у помилках, CORS `Access‑Control‑Allow‑Origin: *` | Імітує реальні атаки — підтверджує експлуатовані runtime‑вразливості і misconfigurations; високий ступінь цінності (PoC доступні) | **Ні** — runtime‑знахідки верифіковано доказами експлуатації (PoC) | ZAP локально не запущено (macOS/Docker обмеження). Натомість виконано ручний DAST (PoC наведено нижче). |




У цій роботі False positives можна вважати:
Якщо знаходите проблему, але розумієте, що вона навмисна (наприклад, у навчальному проєкті), вкажіть це в коментарі.

### DAST (ручне тестування) — знахідки та PoC

- Stored XSS (високий):
  - Endpoint: `PUT /rest/products/1/reviews` — тіло JSON: `{ "author": "attacker@example.com", "message": "<svg/onload=alert('xss')>" }`
  - Перевірка: `GET /rest/products/1/reviews` повертає поле `message` з HTML/JS (не екрановане).
  - Доказ: повідомлення з `<svg/onload=alert('xss')>` присутнє у відповіді (див. `GET /rest/products/1/reviews`).

- Authentication bypass — SQL Injection (критично):
  - Endpoint: `POST /rest/user/login` — тіло JSON: `{ "email": "' OR 1=1 -- ", "password": "x" }`
  - Результат: повертається `authentication.token` для адміністратора (успішний обхід автентифікації).
  - Доказ: відповідь містить `umail: "admin@juice-sh.op"` та токен.

- SQL Injection — search (високий):
  - Endpoint: `GET /rest/products/search?q=<payload>`
  - PoC (boolean): `q=' OR '1'='1' -- ` — повертає розширений набір результатів (SQLi підтверджено).
  - PoC (error disclosure): `q=' UNION SELECT sql FROM sqlite_master -- ` — викликає SQL‑помилку з фрагментом згенерованого SQL (витік).

- Інші конфігураційні/інформаційні проблеми (середні/низькі):
  - Directory listing: `GET /encryptionkeys` (видимі ключі/файли).  
  - Security headers: `Access‑Control‑Allow‑Origin: *` (CORS wildcard); відсутній CSP / HSTS.  
  - Stacktraces visible in error pages (інформаційне розкриття). 

> Команди‑PoC (копіюй/виконуй локально):
> - `curl -X PUT http://localhost:3000/rest/products/1/reviews -H 'Content-Type: application/json' -d '{"author":"attacker@example.com","message":"<svg/onload=alert(\'xss\')>"}'`
> - `curl -H 'Accept: application/json' http://localhost:3000/rest/products/1/reviews`
> - `curl -X POST http://localhost:3000/rest/user/login -H 'Content-Type: application/json' -d '{"email":"' OR 1=1 -- ","password":"x"}' -i`
> - `curl -H 'Accept: application/json' "http://localhost:3000/rest/products/search?q=%27%20OR%20%271%27%3D%271%20--%20"`

---



Якщо Semgrep вказує на проблему у файлі, який зазвичай не використовується в production або не є активною частиною бекенду.



Чекліст перед початком домашнього завдання

Перш ніж переходити до виконання домашнього завдання, переконайтесь, що у вас є результати лабораторної роботи:

- Звіт або скриншоти з OWASP ZAP

Проведено DAST-аналіз, знайдено щонайменше 5 вразливостей.
- Звіт або скриншоти з Semgrep

Проведено SAST-аналіз, знайдено щонайменше 3 вразливості.
- Заповнена таблиця «SAST vs DAST»

Вказано, що виявляє кожен метод, які переваги і недоліки.
- Короткий висновок (2–3 речення)

SAST (Semgrep) швидко знаходить проблемні ділянки в коді — hardcoded секрети, pattern‑based SQLi/XSS; DAST (ZAP) підтверджує експлуатацію та виявляє runtime‑проблеми (XSS, insecure headers). Разом вони доповнюють одне одного: SAST дає контекст у коді, DAST — підтвердження поведінки на runtime.

У чому користь SAST? У чому — DAST?


Ці матеріали ви будете використовувати в домашньому завданні. Окремо їх здавати не потрібно — усе має бути в одному підсумковому документі.